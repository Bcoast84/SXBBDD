iplookup info
-------------

1/ old plugins are not supported anymore

2/ general information in admin settings "Site Administration/Location/Location settings"

3/ technical info:

xplanet commadline
  xplanet -projection rectangular -latitude 0.00  -longitude 0.00  -num_times 1  -geometry 620x310  -output earth.jpeg -quality 90 -config config.txt

config.txt
  [earth]
  shade=100

original Earth map from:
  http://www.radcyberzine.com/xglobe/

marker.gif
  custom made in Inkscape

Petr Skoda (skodak), January 2008  

$Id: README.txt,v 1.1.20.1 2008/01/02 16:49:04 skodak Exp $