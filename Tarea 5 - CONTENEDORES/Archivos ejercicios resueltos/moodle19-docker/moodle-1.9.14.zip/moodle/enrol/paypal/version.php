<?PHP // $Id: version.php,v 1.4 2007/10/10 16:09:51 skodak Exp $

/////////////////////////////////////////////////////////////////////////////////
///  Code fragment to define the version of this enrolment module
///  This fragment is called by admin/index.php
/////////////////////////////////////////////////////////////////////////////////

$plugin->version  = 2006092200;   // This module's version

$plugin->requires = 2007101000;   // Requires this Moodle version

?>
