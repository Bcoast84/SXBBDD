.block_course_summary .content {
    padding:10px;
}

.block_course_summary .editbutton {
    text-align:right;
}
