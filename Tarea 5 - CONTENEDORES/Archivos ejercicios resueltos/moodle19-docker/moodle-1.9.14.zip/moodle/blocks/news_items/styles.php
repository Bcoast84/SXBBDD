.block_news_items .newlink {
  text-align: center;
}
