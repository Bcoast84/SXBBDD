.block_calendar_upcoming .event .date {
    text-align:right;
}
